const Discord = require("discord.js")
module.exports = {
  name: 'test'

  run: (async, message, args) => {
  }
}